// This is the CPP file you will edit and turn in.
// Also remove these comments here and add your own.
// TODO: remove this comment header

#include <iostream>
#include "grid.h"
#include "lifeutil.h"

int main() {

    // TODO: Finish the program!

    std::cout << "Have a nice Life!" << std::endl;
    return 0;
}
