This directory contains any libraries that should be
linked to your project when it is built.
